function btn1(){
var h2 =document.getElementById('h1')
h2.style.fontFamily = "Times New Roman";
}
function btn2(){
    var h2=document.getElementById('h1')
    h2.style.fontSize="100px";
}
function btn3(){
    document.getElementById('h1').style.display="none";
}