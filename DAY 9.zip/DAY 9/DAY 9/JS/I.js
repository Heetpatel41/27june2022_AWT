function image(){
    document.getElementById("r4").src="../HTML/IMAGE/b.jpg";


}
// function d(){
   // document.getElementById("r1").src="../HTML/IMAGE/e.jpg";

    
//}
function f(){
    document.getElementById("r4").src="../HTML/IMAGE/c.jpg";

    
}
function g(){
    document.getElementById("r4").src="../HTML/IMAGE/d.jpg";

    
}